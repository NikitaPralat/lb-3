﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task1.Interfaces
{
    interface IStopwatchModel
    {
        public void Stop();
        public void Pause();
        public void Start();
    }
}
