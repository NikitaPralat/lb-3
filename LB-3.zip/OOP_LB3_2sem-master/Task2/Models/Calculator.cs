﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2.Models
{
    class Calculator
    {
        public string Content { get; set; }
    }
}
